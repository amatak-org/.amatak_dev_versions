#!/usr/bin/env python3
"""Minimal main that redirects."""
from amatak.cli_entry import amatak_main

if __name__ == "__main__":
    amatak_main()